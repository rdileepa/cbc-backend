import express from "express";

const productRouter = express.Router();

productRouter.get("/",(req,res)=>{
    console.log("This is a get request for Product router")
    res.json({
        message: "This is a get request for product router"
    })
})

productRouter.post("/",(req,res)=>{
    console.log("This is a post request for product router")
    res.json({
        message: "This is a post request for product router"
    })
})

export default productRouter;