import express from "express";

import {getStudents,creatStudent, deleteStudent} from "../controllers/studentController.js";

const studentRouter = express.Router();

studentRouter.get("/",getStudents)

studentRouter.post("/",creatStudent)

studentRouter.delete("/",deleteStudent)
export default studentRouter